function loginEventHandler()
{
var userNameElement=document.getElementById("username");
var passwordElement=document.getElementById("password");
var errorMessageElement=document.getElementById("errorMessage");
var userName=userNameElement.value;
var password=passwordElement.value;
errorMessage.style.color="red";
var validationCheck=false;
errorMessageElement.innerHTML="";

if(userName=="")
{
errorMessageElement.innerHTML+="Username cannot be empty";
validationCheck=true;
}

if(password=="")
{
errorMessageElement.innerHTML+="</br>Password cannot be empty";
passwordElement.className="form-control border border-danger border-2";
validationCheck=true;

}
var numberPattern=/[0-9]/;
var numberCheck=numberPattern.test(password);
if(numberCheck==false)
{
errorMessageElement.innerHTML+="</br>Password should contain atleast one digit";
passwordElement.className="form-control border border-danger border-2";
validationCheck=true;
}

var cap=/[A-Z]/;
var capCheck=cap.test(password);
if(capCheck==false)
{
errorMessageElement.innerHTML+="</br>Password should contain atleast one capital letter";
passwordElement.className="form-control border border-danger border-2";
validationCheck=true;

}

var specialChar=/[^a-zA-Z0-9]/;
var sc=specialChar.test(password);
if(sc==false)
{
errorMessageElement.innerHTML+="</br>Password should contain atleast one special character";
passwordElement.className="form-control border border-danger border-2";
validationCheck=true;

}



}
